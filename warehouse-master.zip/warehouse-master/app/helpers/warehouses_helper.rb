module WarehousesHelper
end
